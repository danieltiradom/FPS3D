Font that was used for the background of the preview:
https://www.dafont.com/the-bold-font.font